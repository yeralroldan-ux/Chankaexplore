# Chanka Explore — Android

App Android que muestra https://www.chankaexplore.com/ en un WebView, con enlaces externos (WhatsApp, ATSA, correo, etc.) abiertos fuera de la app.

- applicationId: com.chankaexplore.app
- targetSdk: 36 (Android 16)
- version: 1.0 (versionCode 1)

Para Google Play se debe generar un Android App Bundle (.aab) firmado. Las apps nuevas se publican en AAB.
